
const cropface = document.getElementById("cropimg");

cropimges = ['/static/images/jowarlogo.webp',
                    '/static/images/bajralogo.jpg',
                    '/static/images/cottonlogo.jpg',
                    '/static/images/wheatlogo.avif',
                    '/static/images/sugarcanelogo.jpg']

document.getElementById